# socks5-tool
A very simple socks5 server tool
